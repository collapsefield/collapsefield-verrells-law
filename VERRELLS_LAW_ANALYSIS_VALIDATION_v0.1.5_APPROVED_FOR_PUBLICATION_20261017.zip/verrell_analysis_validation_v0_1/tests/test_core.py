import numpy as np
import pytest
from scipy.stats import binom
from vlsim.score import compatibility
from vlsim.model import probability,multicandidate_probability
from vlsim.dgp import make_trials,dataset,Design
from vlsim.estimate import fit_binary,verdict,heldout_nonlinear_check

def make(kind,seed,n=150,t=16,lam=.7):return make_trials(np.random.default_rng(seed),n,t,kind,lam)
def diag(kind,s1=401,s2=402,n=250,t=16):return heldout_nonlinear_check(make(kind,s1,n,t),make(kind,s2,n,t))
def test_score_and_exact_model():
    assert compatibility([],[],[],[])==0
    assert compatibility([1,1],[1,1],[1,1],[.8,0],normalization='weighted_mean')==pytest.approx(.4)
    with pytest.raises(ValueError):compatibility([-1],[1],[1],[.8])
    from scipy.special import logit
    assert logit(probability(.4,.75,.7))-logit(.4)==pytest.approx(.525)
    assert sum(multicandidate_probability([.5,.5],[.7,-.7],.5))==pytest.approx(1)

def test_immutable_provenance_and_guard():
    from dataclasses import FrozenInstanceError
    d=make('spurious',2,300,40)
    with pytest.raises(FrozenInstanceError):d.design=Design.ASSIGNED
    with pytest.raises(TypeError):fit_binary({**d.__dict__,'design':'randomized_assigned_events'})
    f=fit_binary(d)
    with pytest.raises(FrozenInstanceError):f.design=Design.ASSIGNED
    with pytest.raises(TypeError):verdict({**f.__dict__,'design':Design.ASSIGNED})
    assert verdict(f)['retained_state_effect']=='ineligible_design'
    assert fit_binary(d).provenance_hash==d.provenance_hash

def test_spurious_oracle_and_real_kernel_contrast():
    for kind,seed,sign in [('spurious',2,0),('choice_kernel_own_choices',73,1)]:
        d=make(kind,seed,300,40)
        naive=fit_binary(d)
        # For this synthetic DGP, the true oracle unit preference is regenerated from original RNG below.
        rng=np.random.default_rng(seed);rng.uniform(-1,1,len(d.y));pref=rng.normal(0,.75,300)
        oracle=dataset(d.y,d.r,pref[np.array(d.unit)],d.unit,d.design,d.kind,dict(d.known_truth),'synthetic_oracle_preference_offset')
        corrected=fit_binary(oracle)
        assert naive.lambda_hat>.3
        if sign==0:assert abs(corrected.lambda_hat)<.15
        else:assert corrected.lambda_hat>.3
        assert verdict(corrected)['retained_state_effect']=='ineligible_design'
        if sign==1:assert dict(d.known_truth)['lambda_on_own_choice_R']=='undefined'

def test_recovery_and_mandatory_diagnostic():
    d=make('tilt',33,300,20,.65);f=fit_binary(d)
    assert abs(f.lambda_hat-.65)<.18
    assert verdict(f)['retained_state_effect']=='indeterminate'
    test=make('tilt',34,300,20,.65)
    check=heldout_nonlinear_check(d,test)
    assert verdict(f,diagnostic=check)['retained_state_effect']=='supported_above_meaningful_effect_within_declared_linearity_tolerance'
    other=make('tilt',35,300,20,.65)
    assert verdict(f,diagnostic=heldout_nonlinear_check(other,test))['retained_state_effect']=='indeterminate'

def test_wrong_sign_and_small_effect():
    neg=make('tilt',15,500,25,-.6); tiny=make('tilt',16,600,35,.05)
    assert verdict(fit_binary(neg),diagnostic=heldout_nonlinear_check(neg,make('tilt',115,500,25,-.6)))['retained_state_effect']=='not_supported_wrong_direction'
    assert verdict(fit_binary(tiny),diagnostic=heldout_nonlinear_check(tiny,make('tilt',116,600,35,.05)))['retained_state_effect']!='supported_above_meaningful_effect_within_declared_linearity_tolerance'

def test_separation_and_near_separation():
    r=np.tile([-1.,1.],40)
    d=dataset((r>0).astype(int),r,np.zeros(len(r)),np.arange(len(r)),Design.ASSIGNED,'constructed',{'lambda':None},'synthetic_test_fixture',test_only_fixture=True)
    with pytest.raises(ValueError,match='separation'):fit_binary(d)
    # Large finite slope: refuse Wald inference even if an MLE technically exists.
    rng=np.random.default_rng(11);r=rng.uniform(-1,1,6000);y=rng.binomial(1,1/(1+np.exp(-85*r)))
    d=dataset(y,r,np.zeros(len(r)),np.arange(len(r)),Design.ASSIGNED,'near',{'lambda':85},'synthetic_test_fixture',test_only_fixture=True)
    f=fit_binary(d)
    assert f.near_separation
    assert verdict(f)['retained_state_effect']=='invalid_fit'

def test_multilevel_positive_and_negative_control():
    a=make('tilt',903,450,20,.5);b=make('tilt',904,450,20,.5)
    assert len(np.unique(a.r))>4
    d=heldout_nonlinear_check(a,b)
    assert not d.nonlinear_pattern_flag,d
    assert np.isfinite(d.gain)

def test_nonlinear_holdout_always_required():
    a=make('nonlinear',901,450,20);b=make('nonlinear',902,450,20)
    f=fit_binary(a)
    assert verdict(f)['retained_state_effect']=='indeterminate'
    check=heldout_nonlinear_check(a,b)
    assert check.nonlinear_pattern_flag,check
    assert verdict(f,diagnostic=check)['retained_state_effect']=='linear_tilt_misspecified'

def test_conventional_model_cannot_win_advantage():
    a=make('choice_kernel',52,150,20);b=make('choice_kernel',53,150,20)
    f=fit_binary(a);v=verdict(f,diagnostic=heldout_nonlinear_check(a,b))
    assert v['distinctive_advantage']=='not_evaluated'

def test_underpowered():
    a=make('tilt',7,100,12,.08); f=fit_binary(a)
    b=make('tilt',9,100,12,.08)
    d=heldout_nonlinear_check(a,b)
    assert d.train_hash==f.provenance_hash
    assert f.ci_low<=0 or f.ci_low<.15
    assert verdict(f,diagnostic=d)['retained_state_effect'] not in ('supported_above_meaningful_effect_within_declared_linearity_tolerance','no_meaningful_effect_within_equivalence_margin')

@pytest.mark.slow
def test_calibration_2000_each():
    # Binomial 99.9% acceptance bands, sensitive to approx 3 percentage point error at high power.
    total=2000;rejects=0;covers=0
    for seed in range(total):
        a=fit_binary(make('null',seed,35,12,0));rejects+=(a.p_two_sided<.05)
        b=fit_binary(make('tilt',seed+100000,35,12,.5));covers+=(b.ci_low<=.5<=b.ci_high)
    assert binom.ppf(.0005,total,.05)<=rejects<=binom.ppf(.9995,total,.05),rejects
    assert binom.ppf(.0005,total,.95)<=covers<=binom.ppf(.9995,total,.95),covers

def test_b1_relabelled_own_history_rejected():
    from dataclasses import replace
    d=make('spurious',910,100,15)
    with pytest.raises(ValueError,match='own-choice'):
        replace(d,design=Design.ASSIGNED)
    with pytest.raises(ValueError,match='own-choice'):
        replace(d,design=Design.ASSIGNED,construction='synthetic_independent_assigned_events')
    assert verdict(fit_binary(d))['retained_state_effect']=='ineligible_design'

def test_b2_mismatched_generator_and_row_reuse_refused():
    from dataclasses import replace
    a=make('nonlinear',911,100,15)
    b=make('tilt',912,100,15)
    with pytest.raises(ValueError,match='mismatch'):
        heldout_nonlinear_check(a,b)
    c=make('nonlinear',913,100,15)
    with pytest.raises(ValueError,match='overlapping'):
        heldout_nonlinear_check(a,replace(c,row_ids=a.row_ids))

def test_b3_small_holdout_indeterminate_no_support():
    a=make('nonlinear',914,450,20)
    b=make('nonlinear',915,10,2)
    with pytest.raises(ValueError,match='underpowered'):
        heldout_nonlinear_check(a,b)
    assert verdict(fit_binary(a))['retained_state_effect']=='indeterminate'

def test_heldout_no_history_prediction_mandatory():
    a=make('tilt',916,250,16,.7);b=make('tilt',917,250,16,.7)
    d=heldout_nonlinear_check(a,b)
    assert d.effect_ci_low>0
    assert d.shape_status=='equivalent_within_tolerance'
    assert verdict(fit_binary(a),diagnostic=d)['retained_state_effect']=='supported_above_meaningful_effect_within_declared_linearity_tolerance'
    from dataclasses import replace
    guarded=replace(d,effect_ci_low=-.01)
    assert verdict(fit_binary(a),diagnostic=guarded)['retained_state_effect']=='indeterminate'

def test_shape_equivalence_inconclusive_blocks_support():
    a=make('tilt',918,250,16,.7);b=make('tilt',919,250,16,.7)
    d=heldout_nonlinear_check(a,b)
    from dataclasses import replace
    d=replace(d,shape_status='inconclusive')
    assert verdict(fit_binary(a),diagnostic=d)['retained_state_effect']=='indeterminate'


def test_null_equivalence_reachable():
    a=make('null',202610,600,20,0.); b=make('null',202611,600,20,0.)
    d=heldout_nonlinear_check(a,b)
    v=verdict(fit_binary(a),diagnostic=d)
    assert v['retained_state_effect']=='no_meaningful_effect_within_equivalence_margin', (d,v)

def test_moderate_nonlinear_not_supported_at_planning_size():
    a=make('moderate_nonlinear',101,100,12); b=make('moderate_nonlinear',102,100,12)
    d=heldout_nonlinear_check(a,b)
    v=verdict(fit_binary(a),diagnostic=d)
    assert not v['retained_state_effect'].startswith('supported'), (d,v)

def test_fixture_requires_test_flag():
    r=np.tile([-1.,1.],40)
    with pytest.raises(ValueError,match='test-only'):
        dataset((r>0).astype(int),r,np.zeros(len(r)),np.arange(len(r)),Design.ASSIGNED,'constructed',{'lambda':None},'synthetic_test_fixture')

def test_rewritten_row_ids_and_forged_diagnostic_rejected():
    from dataclasses import replace
    a=make('tilt',315,200,16); b=make('tilt',316,200,16)
    with pytest.raises(ValueError,match='identical'):
        heldout_nonlinear_check(a,replace(a,row_ids=b.row_ids))
    d=heldout_nonlinear_check(a,b)
    forged=replace(d,shape_status='equivalent_within_tolerance',effect_ci_low=999.)
    assert verdict(fit_binary(a),diagnostic=forged)['retained_state_effect']=='indeterminate'


def test_directionally_clear_but_equivalent_small_effect():
    a=make('tilt',4441,1200,20,.05); b=make('tilt',4442,1200,20,.05)
    v=verdict(fit_binary(a),diagnostic=heldout_nonlinear_check(a,b))
    assert v['retained_state_effect']=='no_meaningful_effect_within_equivalence_margin',v
    assert v['direction_significant'] is True

def test_negative_small_effect_canonical_asymmetry():
    a=make('tilt',4451,2500,30,-.08); b=make('tilt',4452,2500,30,-.08)
    v=verdict(fit_binary(a),diagnostic=heldout_nonlinear_check(a,b))
    assert v['retained_state_effect']=='not_supported_wrong_direction',v
    assert v['direction_significant'] is True

def test_positive_verdict_explicitly_names_tolerance():
    a=make('tilt',4461,300,16,.7);b=make('tilt',4462,300,16,.7)
    v=verdict(fit_binary(a),diagnostic=heldout_nonlinear_check(a,b))
    assert 'within_declared_linearity_tolerance' in v['retained_state_effect'],v
    assert v['linearity_tolerance_nats_per_choice']==.002

def test_moderate_saturation_multiseed_no_positive_support():
    for seed in range(20):
        a=make('moderate_nonlinear',60000+2*seed,100,12)
        b=make('moderate_nonlinear',60001+2*seed,100,12)
        v=verdict(fit_binary(a),diagnostic=heldout_nonlinear_check(a,b))
        assert not v['retained_state_effect'].startswith('supported'),(seed,v)
