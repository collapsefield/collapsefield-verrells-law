"""Standalone Route B analysis-validation simulator. Not empirical confirmation."""
__version__='0.1.5'
