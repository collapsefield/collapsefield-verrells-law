"""Synthetic DGPs with known truths. These are engineering checks, not empirical findings."""
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
import hashlib

class Design(str, Enum):
    ASSIGNED = "randomized_assigned_events"
    OWN = "own_prior_selections"
    UNKNOWN = "observational_unknown"

@dataclass(frozen=True)
class TrialData:
    y: tuple
    r: tuple
    offset: tuple
    unit: tuple
    design: Design
    kind: str
    known_truth: tuple
    construction: str
    row_ids: tuple = ()
    test_only_fixture: bool = False
    provenance_hash: str = field(init=False)

    def __post_init__(self):
        if self.kind in ('spurious', 'choice_kernel_own_choices') and (self.design != Design.OWN or self.construction not in ('synthetic_own_prior_choices','synthetic_oracle_preference_offset')):
            raise ValueError('own-choice DGP incompatible with assigned design or construction')
        if self.construction == 'synthetic_independent_assigned_events' and self.design != Design.ASSIGNED:
            raise ValueError('synthetic assigned construction incompatible with design')
        if self.construction == 'synthetic_test_fixture' and not self.test_only_fixture:
            raise ValueError('synthetic_test_fixture requires explicit test-only flag')
        if self.design == Design.ASSIGNED and self.construction not in ('synthetic_independent_assigned_events', 'synthetic_test_fixture'):
            raise ValueError('assigned design requires declared allowed construction')
        if self.row_ids and len(self.row_ids) != len(self.y):
            raise ValueError('row IDs misaligned')
        payload = repr((self.y,self.r,self.offset,self.unit,self.design.value,self.kind,self.known_truth,self.construction,self.row_ids,self.test_only_fixture))
        object.__setattr__(self, "provenance_hash", hashlib.sha256(payload.encode()).hexdigest())

def dataset(y,r,offset,unit,design,kind,known_truth,construction,row_ids=None, test_only_fixture=False):
    if not isinstance(design,Design): raise ValueError("design must be a Design enum")
    return TrialData(tuple(int(v) for v in y),tuple(float(v) for v in r),tuple(float(v) for v in offset),tuple(int(v) for v in unit),design,kind,tuple(sorted(known_truth.items())),construction,tuple(row_ids) if row_ids is not None else (),test_only_fixture)


from scipy.special import expit

def make_trials(rng, n_units=100, trials_per_unit=10, kind='tilt', true_lambda=0.7):
    if n_units < 2 or trials_per_unit < 2:
        raise ValueError('n_units and trials_per_unit must be >=2')
    uid=np.repeat(np.arange(n_units),trials_per_unit)
    n=len(uid)
    assigned=rng.uniform(-1.,1.,size=n)  # continuous assigned histories allow nonlinear checks
    # Baseline propensity varies per unit. Model knows baseline odds; no binary "memory off" claim.
    preferences=rng.normal(0,0.75,n_units)
    offset=preferences[uid]
    r=assigned.copy()
    if kind=='null':
        logits=offset
    elif kind=='tilt':
        logits=offset+true_lambda*r
    elif kind in ('nonlinear','moderate_nonlinear','mild_nonlinear'):
        # r has continuous values here to identify nonlinear misspecification.
        r=rng.uniform(-1,1,n)
        logits=offset+(2.4*np.tanh(4*r)+1.2*r*r if kind=='nonlinear' else (1.0*np.tanh(3*r) if kind=='moderate_nonlinear' else 0.8*np.tanh(1.5*r)))
    elif kind=='choice_kernel':
        # A conventional sequential-choice model where past choices affect next choices;
        # experimental R is unrelated independently assigned events.
        logits=np.empty(n)
        y=np.empty(n,dtype=int)
        for u in range(n_units):
            last=0.0
            for t in range(trials_per_unit):
                i=u*trials_per_unit+t
                logits[i]=offset[i]+0.9*last
                y[i]=int(rng.random()<expit(logits[i]))
                last=2*y[i]-1
        return dataset(y,r,offset,uid,Design.ASSIGNED,kind,{'lambda':0.0,'process':'choice_kernel_last_choice','kernel_coefficient':0.9},'synthetic_independent_assigned_events',rng.integers(0,2**62,size=n))
    elif kind in ('spurious','choice_kernel_own_choices'):
        # R derives from the participant's own preceding choices;
        # this is not an independently assigned R and is causally invalid for a naive test.
        y=np.empty(n,dtype=int)
        for u in range(n_units):
            for t in range(trials_per_unit):
                i=u*trials_per_unit+t
                y[i]=int(rng.random()<expit(offset[i]+(0.9*(2*y[i-1]-1) if kind=='choice_kernel_own_choices' and t>0 else 0.)))
        r=np.zeros(n)
        for u in range(n_units):
            for t in range(trials_per_unit):
                i=u*trials_per_unit+t
                past=y[u*trials_per_unit+max(0,t-5):i]
                r[i]=float(np.mean(2*past-1)) if len(past) else 0.
        truth={'lambda_on_own_choice_R':'undefined', 'kernel_coefficient':0.9 if kind=='choice_kernel_own_choices' else 0.0, 'oracle_preference_sd':0.75}
        return dataset(y,r,np.zeros(n),uid,Design.OWN,kind,truth,'synthetic_own_prior_choices',rng.integers(0,2**62,size=n))
    else:
        raise ValueError('unknown DGP')
    y=rng.binomial(1,expit(logits))
    truth={'lambda':None if kind in ('nonlinear','moderate_nonlinear','mild_nonlinear') else (0.0 if kind=='null' else true_lambda),'process':kind}
    return dataset(y,r,offset,uid,Design.ASSIGNED,kind,truth,'synthetic_independent_assigned_events',rng.integers(0,2**62,size=n))
