"""Declared exponential-tilt models. Not a physical validation."""
import numpy as np
from scipy.special import expit, logit

def probability(p0, r, lam):
    p0 = np.asarray(p0, dtype=float)
    r = np.asarray(r, dtype=float)
    if not np.all(np.isfinite(p0)) or not np.all((p0 > 0) & (p0 < 1)):
        raise ValueError('p0 must be finite and strictly between 0 and 1')
    if not np.all(np.isfinite(r)) or not np.isfinite(lam):
        raise ValueError('R and lambda must be finite')
    return expit(logit(p0) + lam * r)

def multicandidate_probability(p0, scores, lam):
    from scipy.special import logsumexp
    p0 = np.asarray(p0, dtype=float)
    scores = np.asarray(scores, dtype=float)
    if p0.ndim != 1 or scores.shape != p0.shape or len(p0) < 2:
        raise ValueError('p0 and scores must be same one-dimensional candidate vector')
    if not np.all(np.isfinite(p0)) or np.any(p0 <= 0) or not np.isclose(p0.sum(), 1):
        raise ValueError('p0 must be positive and sum to one')
    if not np.all(np.isfinite(scores)) or not np.isfinite(lam):
        raise ValueError('nonfinite score or lambda')
    z = np.log(p0) + lam * scores
    return np.exp(z-logsumexp(z))
