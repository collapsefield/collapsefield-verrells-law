import argparse, hashlib, json, platform
from pathlib import Path
import numpy as np
import scipy
from . import __version__
from .dgp import make_trials
from .estimate import fit_binary, verdict, heldout_nonlinear_check

def main():
    ap=argparse.ArgumentParser(description='Synthetic Route B analysis validation; NOT a physical-law test')
    sub=ap.add_subparsers(dest='command',required=True)
    r=sub.add_parser('run');r.add_argument('--config',required=True);r.add_argument('--seed',required=True,type=int);r.add_argument('--output',required=True)
    args=ap.parse_args();raw=Path(args.config).read_bytes();cfg=json.loads(raw)
    allowed={'n_units','trials_per_unit','kind','true_lambda','min_effect'}
    if set(cfg)-allowed:raise ValueError('unknown config keys')
    params={k:v for k,v in cfg.items() if k!='min_effect'}
    train=make_trials(np.random.default_rng(args.seed),**params)
    test=make_trials(np.random.default_rng(args.seed+1000003),**params)
    fitted=fit_binary(train)
    try: diagnostic=heldout_nonlinear_check(train,test)
    except ValueError as e: diagnostic=None;diagnostic_error=str(e)
    else:diagnostic_error=None
    v=verdict(fitted,min_effect=cfg.get('min_effect',.15),diagnostic=diagnostic)
    truth=dict(train.known_truth)
    report={'run_type':'Route B: constructed analysis-validation','not_scientific_confirmation':True,'version':__version__,
        'seed':args.seed,'config':cfg,'config_sha256':hashlib.sha256(raw).hexdigest(),
        'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
        'known_truth':{'dgp':train.kind,**truth,'design':train.design.value},
        'provenance':{'construction':train.construction,'train_sha256':train.provenance_hash,'heldout_sha256':test.provenance_hash},
        'estimate':{k:getattr(fitted,k) for k in ('lambda_hat','se','ci_low','ci_high','p_two_sided','intercept_hat','n','converged','near_separation','separation')},
        'heldout_diagnostic':None if diagnostic is None else {k:getattr(diagnostic,k) for k in ('gain','ci_low','ci_high','nonlinear_pattern_flag','calibration','shape_status','effect_gain','effect_ci_low','effect_ci_high','test_n')},
        'diagnostic_error':diagnostic_error,'verdict':v,
        'evidence_types':{'score_differences':'not_observed','winner_changes':'not_observed','choice_outcomes_observed':len(train.y),'choice_probabilities':'estimated_from_synthetic_outcomes'}}
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,sort_keys=True,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n')
    print(json.dumps({'output':str(out),'estimate':fitted.lambda_hat,'verdict':v['retained_state_effect'],'warning':'Route B; not empirical confirmation'}))
if __name__=='__main__':main()
