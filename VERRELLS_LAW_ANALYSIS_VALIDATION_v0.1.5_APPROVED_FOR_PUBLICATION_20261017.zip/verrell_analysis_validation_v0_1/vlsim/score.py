"""Predeclared scoring conventions; never silently clip invalid inputs."""
import numpy as np

def compatibility(salience, persistence, reliability, signed_relevance, normalization='mean_n'):
    s,d,q,r = (np.asarray(x,dtype=float) for x in (salience,persistence,reliability,signed_relevance))
    if any(x.ndim != 1 for x in (s,d,q,r)) or not(s.shape==d.shape==q.shape==r.shape):
        raise ValueError('all four inputs must be same length one-dimensional vectors')
    if any(not np.all(np.isfinite(x)) for x in (s,d,q,r)):
        raise ValueError('non-finite or missing weight')
    if any(np.any((x<0)|(x>1)) for x in (s,d,q)) or np.any((r< -1)|(r>1)):
        raise ValueError('weights must be in [0,1], relevance in [-1,1]')
    if normalization not in ('mean_n','weighted_mean'):
        raise ValueError('unknown normalization')
    if len(s)==0:
        return 0.0
    w=s*d*q
    if normalization=='mean_n':
        return float(np.sum(w*r)/len(s))
    den=float(np.sum(w))
    if den==0:
        raise ValueError('zero denominator for weighted mean (unless history empty)')
    return float(np.sum(w*r)/den)
