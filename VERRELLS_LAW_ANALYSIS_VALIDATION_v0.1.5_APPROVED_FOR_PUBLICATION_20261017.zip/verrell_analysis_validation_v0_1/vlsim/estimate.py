"""Synthetic oracle-offset estimators and fail-closed analysis checks; not human-data inference."""
from dataclasses import dataclass
import hashlib
import numpy as np
from scipy.optimize import root, linprog, minimize
from scipy.special import expit
from scipy.stats import norm
from .dgp import Design, TrialData

@dataclass(frozen=True)
class Fit:
    lambda_hat: float
    se: float
    ci_low: float
    ci_high: float
    p_two_sided: float
    intercept_hat: float
    n: int
    design: Design
    provenance_hash: str
    converged: bool
    near_separation: bool
    separation: bool
    known_oracle_offset: bool = True
    def __getitem__(self,key): return getattr(self,key)

@dataclass(frozen=True)
class Diagnostic:
    gain: float
    ci_low: float
    ci_high: float
    nonlinear_pattern_flag: bool
    eligible: bool
    train_hash: str
    test_hash: str
    calibration: str
    shape_status: str = 'inconclusive'
    effect_gain: float = float('nan')
    effect_ci_low: float = float('nan')
    effect_ci_high: float = float('nan')
    test_n: int = 0
    train_data: TrialData | None = None
    test_data: TrialData | None = None
    tolerance: float = .002
    alpha: float = .05
    def __getitem__(self,key):return getattr(self,key)

def _sep(X,y):
    signed=(2*y-1)[:,None]*X
    A=np.concatenate([signed,-signed],axis=1)
    z=linprog(-A.sum(axis=0),A_ub=np.vstack([-A,np.ones((1,A.shape[1]))]),b_ub=np.r_[np.zeros(len(y)),1.],bounds=[(0,None)]*A.shape[1],method='highs')
    return bool(z.success and -z.fun>1e-7)

def fit_binary(data,alpha=.05):
    if not isinstance(data,TrialData):raise TypeError('fit_binary requires immutable TrialData; dict metadata is not trusted')
    if data.design not in Design: raise ValueError('invalid design')
    y=np.asarray(data.y,dtype=float); r=np.asarray(data.r); off=np.asarray(data.offset)
    if y.ndim!=1 or len(y)<5 or y.shape!=r.shape or r.shape!=off.shape or len(y)!=len(data.unit):raise ValueError('arrays misaligned')
    if not np.all(np.isin(y,[0,1])) or not np.all(np.isfinite(r)) or not np.all(np.isfinite(off)) or np.std(r)<1e-10:raise ValueError('bad data')
    if not 0<alpha<1:raise ValueError('bad alpha')
    X=np.column_stack([np.ones(len(y)),r])
    if _sep(X,y):raise ValueError('complete or quasi-separation detected')
    def gradient(beta):return X.T@(expit(off+X@beta)-y)
    o=root(gradient,[0.,0.],method='hybr',options={'xtol':1e-9})
    if not o.success or np.linalg.norm(gradient(o.x))>1e-5:raise ValueError('optimizer non-convergence')
    b=o.x; probs=expit(off+X@b)
    h=X.T@((probs*(1-probs))[:,None]*X)
    if np.linalg.cond(h)>1e10:raise ValueError('near-singular information')
    se=float(np.sqrt(np.linalg.inv(h)[1,1])); est=float(b[1]); z=norm.ppf(1-alpha/2)
    # Conservative screen; a finite MLE with extreme contrast still has unreliable Wald inference.
    near=bool(abs(est)*(float(r.max())-float(r.min()))>12 or (np.min(probs)<1e-7 or np.max(probs)>1-1e-7))
    return Fit(est,se,est-z*se,est+z*se,float(2*norm.sf(abs(est/se))),float(b[0]),len(y),data.design,data.provenance_hash,True,near,False)

def _basis_fit(train, degree):
    y=np.asarray(train.y);r=np.asarray(train.r);off=np.asarray(train.offset)
    X=np.column_stack([r**j for j in range(degree+1)])
    if np.linalg.matrix_rank(X)<degree+1:raise ValueError('nonlinear diagnostic unidentifiable: insufficient predictor levels')
    if _sep(X,y):raise ValueError('diagnostic design separation')
    def grad(b):return X.T@(expit(off+X@b)-y)
    o=root(grad,np.zeros(degree+1),method='hybr',options={'xtol':1e-8})
    if not o.success or np.linalg.norm(grad(o.x))>1e-5:raise ValueError('diagnostic non-convergence')
    return o.x

def _unit_ci(gain,units,alpha):
    u=np.asarray(units); ids=np.unique(u)
    if len(ids)<30 or len(gain)<300:
        raise ValueError('underpowered held-out split: >=30 units and >=300 observations required')
    per=np.array([np.mean(gain[u==i]) for i in ids]); mean=float(np.mean(per))
    se=float(np.std(per,ddof=1)/np.sqrt(len(per))); zcrit=norm.ppf(1-alpha/2)
    return mean,mean-zcrit*se,mean+zcrit*se

def heldout_nonlinear_check(train,test,alpha=.05,nonlinearity_tolerance=.002):
    """Synthetic held-out equivalence screen and offset-only predictive comparison.
    These two comparisons are necessary, not sufficient, for real-world validity.
    """
    if not isinstance(train,TrialData) or not isinstance(test,TrialData):raise TypeError('TrialData required')
    if train.design!=Design.ASSIGNED or test.design!=Design.ASSIGNED:raise ValueError('ineligible design')
    if train.kind!=test.kind or train.construction!=test.construction or train.known_truth!=test.known_truth:
        raise ValueError('held-out data generation/protocol mismatch')
    if train.provenance_hash==test.provenance_hash:raise ValueError('same held-out dataset')
    if not train.row_ids or not test.row_ids or set(train.row_ids).intersection(test.row_ids):
        raise ValueError('missing row provenance or overlapping held-out rows')
    # Synthetic integrity only: replacing all row IDs on identical records must not bypass disjointness.
    if (train.y,train.r,train.offset,train.unit)==(test.y,test.r,test.offset,test.unit):
        raise ValueError('identical train/test content despite different row IDs')
    if not 0<alpha<1 or not np.isfinite(nonlinearity_tolerance) or nonlinearity_tolerance<=0:
        raise ValueError('invalid analysis plan')
    r=np.asarray(test.r);y=np.asarray(test.y);off=np.asarray(test.offset)
    losses=[]
    for degree in (1,3):
        b=_basis_fit(train,degree)
        z=off+np.column_stack([r**j for j in range(degree+1)])@b
        losses.append(np.logaddexp(0,z)-y*z)
    shape=np.asarray(losses[0])-np.asarray(losses[1])
    mean,lo,hi=_unit_ci(shape,test.unit,alpha)
    status='misspecified' if lo>0 else ('equivalent_within_tolerance' if hi<nonlinearity_tolerance else 'inconclusive')
    # Fair no-history comparison: allow the baseline its own fitted intercept.
    ytr=np.asarray(train.y);otr=np.asarray(train.offset)
    def null_score(v): return np.sum(expit(otr+v)-ytr)
    from scipy.optimize import brentq
    try: b0=brentq(null_score,-30.,30.)
    except ValueError: raise ValueError('baseline null intercept failed')
    znull=off+b0
    null_loss=np.logaddexp(0,znull)-y*znull
    eff,elo,ehi=_unit_ci(null_loss-np.asarray(losses[0]),test.unit,alpha)
    return Diagnostic(mean,float(lo),float(hi),bool(lo>0),True,train.provenance_hash,test.provenance_hash,
                      'unit_clustered_asymptotic_holdout_ci_with_equivalence_screen',status,eff,float(elo),float(ehi),len(test.y),train,test,float(nonlinearity_tolerance),float(alpha))

def verdict(fit,min_effect=.15,diagnostic=None):
    if not isinstance(fit,Fit):raise TypeError('immutable Fit required; dict relabeling refused')
    if not np.isfinite(min_effect) or min_effect<=0:raise ValueError('bad minimum effect')
    def make(label,reason):
        direction_significant = bool(np.isfinite(fit.ci_low) and np.isfinite(fit.ci_high) and (fit.ci_low > 0 or fit.ci_high < 0))
        return {'retained_state_effect':label,'distinctive_advantage':'not_evaluated',
                'direction_significant':direction_significant,'linearity_tolerance_nats_per_choice':(diagnostic.tolerance if isinstance(diagnostic,Diagnostic) else None),
                'reason':reason}
    if fit.design!=Design.ASSIGNED:return make('ineligible_design','nonrandom or own-choice derived design; cannot infer causality from association')
    if not fit.converged or fit.separation or fit.near_separation:return make('invalid_fit','failed fit or potential extreme/near separation; Wald inference withheld')
    if not isinstance(diagnostic,Diagnostic) or not diagnostic.eligible or diagnostic.train_hash!=fit.provenance_hash:
        return make('indeterminate','mandatory independently held-out model diagnostic absent, ineligible, or mismatched')
    # Recompute from the recorded trial datasets, never trust edited diagnostic conclusions.
    if diagnostic.train_data is None or diagnostic.test_data is None:
        return make('indeterminate','diagnostic lacks inspectable trial provenance')
    try:
        check=heldout_nonlinear_check(diagnostic.train_data,diagnostic.test_data,diagnostic.alpha,diagnostic.tolerance)
        if check!=diagnostic: return make('indeterminate','diagnostic integrity check failed')
    except (ValueError,TypeError):
        return make('indeterminate','held-out diagnostic could not be independently recomputed')
    if diagnostic.shape_status=='misspecified':return make('linear_tilt_misspecified','held-out cubic basis predicts more accurately; history effect may still exist')
    if diagnostic.shape_status!='equivalent_within_tolerance':return make('indeterminate','held-out shape equivalence inconclusive')
    lo,hi=fit.ci_low,fit.ci_high
    # Null or wrong-sign verdicts do not require an improvement over the no-history model.
    if hi<0:label='not_supported_wrong_direction'
    elif lo>-min_effect and hi<min_effect:
        label='no_meaningful_effect_within_equivalence_margin'
    elif lo>0:
        if not np.isfinite(diagnostic.effect_ci_low) or diagnostic.effect_ci_low<=0:
            return make('indeterminate','held-out tilt has not demonstrated improved prediction over no-history baseline')
        label=('supported_above_meaningful_effect_within_declared_linearity_tolerance' if lo>min_effect
               else 'positive_below_or_not_clearly_above_meaningful_effect')
    else:label='indeterminate'
    return make(label,'Synthetic oracle-offset inference, with linear shape assessed only within the stated held-out tolerance; no independent real-system evidence or comparator fitting. Negative direction is a separately specified canonical falsifier, even below the meaningful positive-effect margin.')
