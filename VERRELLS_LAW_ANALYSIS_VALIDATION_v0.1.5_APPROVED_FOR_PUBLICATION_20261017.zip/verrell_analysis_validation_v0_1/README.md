# Verrell's Law — Analysis-Validation v0.1.5 (Route B release)

**Status:** Release-approved research tool package, Route B synthetic analysis validation (17 October 2026); awaiting repository upload. Not a test or confirmation of a law of nature. No Collapse Aware AI code or implementation details included.

## Intended scope

Checks a known-offset synthetic binary-choice analysis pipeline for parameter recovery, null type-I error, interval coverage, design eligibility, extreme-separation hazards, and held-out nonlinear-model failure. The simulator constructs its own truths: fitting those truths is software conformance, not empirical corroboration.

## Fail-closed rules

- The synthetic DGP returns immutable `TrialData` records, storing all observations as tuples, a `Design` enum and a reproducibility hash over the construction descriptor, design and values. `fit_binary` rejects plain dictionaries; it returns an immutable `Fit` containing design and provenance. `verdict` rejects dictionaries.
- **This is not cryptographic proof of random assignment.** Construction/design consistency is checked for supported synthetic kinds; `dataclasses.replace()` cannot directly recast an own-choice DGP as assigned. A knowledgeable caller can still forge a coherent `TrialData`, and Python code is not tamper-resistant. A real experiment requires an independently checked protocol and loader. This guard reduces accidental relabeling, not deliberate fraud.
- `own_prior_selections` and `observational_unknown` cannot receive an eligible causal verdict; increasing sample size does not repair their confounding.
- Even an `ASSIGNED` dataset does not automatically make post-treatment `R` exogenous. Current generator uses independently assigned synthetic `r` values.
- No "supported" verdict without a **construction-matched, row-disjoint, adequately sized held-out nonlinear equivalence check AND demonstrated improvement against the no-history baseline model (with its own fitted intercept)**. It is fitted and reported for ALL CLI kinds, never conditionally on the known DGP truth. Missing, failed or mismatched diagnostics return `indeterminate`.
- Complete/quasi separation fails fitting; extreme but finite near-separation is flagged and blocks Wald-based support. A profile-likelihood or bias-reduced alternative is NOT implemented.
- A positive relationship is distinct from a measured changed winner, and from distinctive advantage over conventional history models. `distinctive_advantage` always remains `not_evaluated`.

## Held-out diagnostic limitations

A cubic-versus-linear model is fitted only on training data. Per-unit held-out mean loss differences receive an asymptotic cluster-level CI. Misspecification is flagged when the lower CI bound exceeds zero; linear shape is provisionally accepted only when the upper CI bound is below the provisional 0.002-nats/choice tolerance. Otherwise the result is indeterminate. Positive support requires held-out improvement over a no-history model that is allowed its own fitted intercept, with a positive lower CI bound. An adequately precise null/equivalence or wrong-sign verdict does **not** require held-out improvement. Minimum held-out sample: 30 units and 300 observations. This is a **screening test, not a calibrated universal specification test**. It can miss moderate or mild saturation and does not prove correct specification when unflagged. A limited v0.1.5 sanity probe (20 synthetic seeds per truth, non-preregistered and not a power assessment) produced the following. This table reports **verdicts** rather than merely misspecification flags:

| Truth | Sample per split | Supported | Not supported/equivalent | Misspecified | Indeterminate |
|---|---:|---:|---:|---:|---:|
| Null | 600 units × 20 | 0 | 20 | 0 | 0 |
| Linear tilt λ=0.7 | 250 units × 16 | 19 | 0 | 1 | 0 |
| Moderate saturation | 100 units × 12 | 0 | 0 | 5 | 15 |
| Mild saturation | 100 units × 12 | 13 | 0 | 0 | 7 |

**Key limitation:** the `supported_above_meaningful_effect_within_declared_linearity_tolerance` verdict means the nonlinear diagnostic stayed within 0.002 nats per choice; it does not certify exact linearity. Mild departures smaller than 0.002 nats per choice can still yield positive-support verdicts. The word *supported* means the synthetic linear-tolerance protocol was passed, not that genuine linearity was established or that competing history models were beaten. The one false misspecification flag under linear tilt also shows the shape screen has non-zero false-flag risk. Its joint operating characteristics require more calibration before scientific use.

## Run

Requires Python 3.11+, numpy, scipy, pytest for tests. From project root:

```bash
python -m vlsim run --config example.json --seed 17 --output results/v015_example.json
python -m pytest -q -m 'not slow'
python -m pytest -q -m slow
```

The slow test runs 2,000 independent null and 2,000 positive-tilt replicates. Its acceptance bounds detect approximately three percentage points of miscalibration with high probability; smaller deviations can pass. Standard errors assume conditionally independent binary choices given the synthetic **oracle-known** baseline offsets. No human-data application is warranted from this test.

## Explicitly OUT of scope

No human-data loader; no independently validated human `R`; no preregistration; no ethics approval; no inferred causal findings in real systems; no observational baseline inference; no estimated baseline for real subjects; no profile-likelihood or Firth estimator; no universal nonlinear calibration; no power planner; no conventional comparator fitting; no shuffled / irrelevant / ablation control battery; no deterministic raw-score or observed-probability inference paths. None of these should be implied by the package title or CLI labels.

The `choice_kernel_own_choices` generator's true kernel coefficient is 0.9 on the last previous choice; its coefficient for the average-five-choice `R` is **undefined**, not 0.9. A paired synthetic oracle-offset illustration shows that correcting true known individual preferences removes a spurious association, but not a genuine kernel-driven association. Both are blocked for causal interpretation based on own-choice `R`.

Author/originator of research framework: Marcos Verrell Moss Ross (M.R.). This tool is a Route B synthetic analysis-validation utility and does not establish physical claims.

## v0.1.5 repair caveats

Row identifiers are synthetic RNG-generated per observation and prevent accidental row reuse; they are not an auditable real-data ingestion mechanism. Train/test `kind`, construction and known-truth tuples must match, a condition limited to synthetic experiments where truth is known. The current held-out equivalence and improvement CIs are asymptotic unit-clustered tests; their joint operating characteristics are not fully calibrated, and the equivalence tolerance is provisional. No human-data inference or distinctive-model claim is justified. A frozen `Fit` is not an integrity-protected fit: deliberate use of `dataclasses.replace` can change confidence fields, and a single recomputing `analyse(train, test)` entry point remains outside this release. Near-duplicate held-out records are not detected, only exact duplicate content. The near-separation screening cutoffs are heuristic and uncalibrated. The CLI with 100 units × 12 trials can correctly return indeterminate for a true tilt because the held-out conditions are stringent.

## v0.1.5 corrections

- The null/equivalence verdict is now reachable; held-out improvement blocks only a positive verdict.
- Shape-equivalence tolerance tightened from 0.01 to 0.002 nats per choice. The number remains a provisional engineering choice, not an empirical smallest-effect threshold.
- The no-history comparator has its own train-fitted intercept.
- `synthetic_test_fixture` requires an explicit test-only argument. Synthetic provenance is not a security boundary.
- The verdict recomputes the diagnostic from its retained train/test trials, detecting edited diagnostic summaries; this makes verdict evaluation more computationally expensive and does not prove authentic data provenance.
- Exact duplicated train/test content with different row IDs is blocked; independent row-level traceability and forged coherent data remain out of scope.
- The earlier `test_underpowered` was replaced by a diagnostic-present low-power path.

This narrow Route B release has been reviewed against the documented synthetic tests. It has not been validated for human data, causal claims, or independent scientific confirmation; no CAAI source code is included.

## v0.1.5 release-terminology clarification

- An effect with a confidence interval wholly inside the declared ±0.15 meaningful-effect margin receives `no_meaningful_effect_within_equivalence_margin` (the current implementation uses a conservative 95% CI, rather than a 90% TOST interval). An effect may be statistically distinguishable from zero yet be too small to count as meaningful. The JSON verdict reports `direction_significant` separately.
- Reliably negative coefficients receive `not_supported_wrong_direction`, even if their magnitude lies below the positive meaningful-effect margin. This deliberate asymmetry follows the directional canonical hypothesis and is not an assertion that the negative effect is practically large.
- Positive substantive verdicts explicitly include `within_declared_linearity_tolerance`; the associated JSON reports `linearity_tolerance_nats_per_choice`. A positive verdict does not prove exact model specification.
- The packaged example uses 250 units × 16 trials per split for a more informative demonstration. Smaller 100 × 12 trials can correctly return indeterminate for a true tilt; the CLI does not guarantee support.
