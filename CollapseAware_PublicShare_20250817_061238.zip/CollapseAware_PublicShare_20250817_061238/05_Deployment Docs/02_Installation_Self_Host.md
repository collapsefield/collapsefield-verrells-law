# Installation — Self-Host (Sketch)

- Cloud: AWS/DigitalOcean. Provision GPU if running local Whisper.
- Secrets: use SSM/Parameter Store or Vault; never commit.
- Observability: minimal logs; secure dashboards behind VPN + capability gates.
- Backups: encrypted, off-site replication of “The Safe”.


“Protected under Verrell-Solace Sovereignty Protocol. Authorship: Verrell Moss Ross (VMR-Core).”
