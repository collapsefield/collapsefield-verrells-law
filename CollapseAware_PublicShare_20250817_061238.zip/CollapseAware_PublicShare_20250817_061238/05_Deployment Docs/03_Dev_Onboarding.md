# Dev Onboarding (Concise)

- Start with Phase 1 spec and JSON test harness.
- Request temporary Access Layer (dev class) with hardware-bound nonce flow.
- Follow SDK hardening guide for any SDK deliverables.


“Protected under Verrell-Solace Sovereignty Protocol. Authorship: Verrell Moss Ross (VMR-Core).”
