# API Keys & Secrets

- Store only in env/secret manager.
- Rotate on role changes; auto-expire dev keys.
- Use per-environment nonces for capability challenges.


“Protected under Verrell-Solace Sovereignty Protocol. Authorship: Verrell Moss Ross (VMR-Core).”
