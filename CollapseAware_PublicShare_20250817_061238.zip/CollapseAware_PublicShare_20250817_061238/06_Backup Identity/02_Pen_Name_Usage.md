# Pen Name Usage

- Publish as **M.R.** for stealth and separation.
- Keep legal names out of public repos unless contractually required.


“Protected under Verrell-Solace Sovereignty Protocol. Authorship: Verrell Moss Ross (VMR-Core).”
