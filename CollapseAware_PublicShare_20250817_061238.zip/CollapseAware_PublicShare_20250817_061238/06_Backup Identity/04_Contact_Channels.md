# Contact Channels (Public-Facing)

- Email alias(es) under CollapseField/VMR-Core umbrellas.
- Do not publish personal numbers or private addresses.


“Protected under Verrell-Solace Sovereignty Protocol. Authorship: Verrell Moss Ross (VMR-Core).”
